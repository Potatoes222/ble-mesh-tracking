#pragma once

#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>

void bmt_auth_init(void);

bool bmt_auth_verify_tag(uint16_t tag_id, const uint8_t* data, int len, uint16_t received_mac);

int32_t bmt_auth_get_locked_epoch(uint16_t tag_id);

uint16_t bmt_auth_ota_beacon_hmac16(const uint8_t* data, size_t len);

void bmt_auth_set_ota_beacon_key(const uint8_t* key, size_t len);
