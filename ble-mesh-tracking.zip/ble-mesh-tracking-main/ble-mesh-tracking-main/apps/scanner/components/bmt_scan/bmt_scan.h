#pragma once

#include "esp_err.h"

esp_err_t bmt_scan_start(void);
