#pragma once

#include <stdint.h>

#include "esp_err.h"
#define BMT_SCAN_NVS_NAMESPACE "bmt_scan"

esp_err_t bmt_scan_core_init(void);

uint8_t bmt_scan_core_scanner_id(void);
void bmt_scan_core_set_scanner_id(uint8_t id);
