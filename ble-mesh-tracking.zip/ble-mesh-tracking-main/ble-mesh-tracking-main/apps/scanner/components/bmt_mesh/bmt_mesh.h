#pragma once

#include <stdint.h>

#include "esp_err.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"

#define BMT_PROV_COMPLETE_BIT BIT0

esp_err_t bmt_mesh_init(void);

EventGroupHandle_t bmt_mesh_evgrp(void);

uint16_t bmt_mesh_node_addr(void);
uint16_t bmt_mesh_app_idx(void);

const uint8_t* bmt_mesh_uuid(void);

void bmt_mesh_publish_tags(void);

esp_err_t bmt_mesh_report_ota_result(uint8_t status);

void bmt_mesh_local_reset(void);
