#pragma once

#include <stdbool.h>
#include <stdint.h>

int bmt_battery_init(void);

int bmt_battery_read_mv(void);

uint8_t bmt_battery_percent(int mv);

bool bmt_battery_is_charging(void);

uint8_t bmt_battery_last_percent(void);
