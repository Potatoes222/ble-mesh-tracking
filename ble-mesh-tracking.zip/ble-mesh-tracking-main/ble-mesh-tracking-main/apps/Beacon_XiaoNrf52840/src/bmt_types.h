#pragma once

#include <stdint.h>

#pragma pack(1)
typedef struct
{
	uint8_t uuid[16];
	uint16_t battery;
	uint16_t minor;
	int8_t tx_power;
	uint8_t sequence;
	uint16_t mac16;
} bmt_tag_adv_payload_t;
#pragma pack()
