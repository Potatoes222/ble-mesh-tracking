#pragma once

#include <stddef.h>
#include <stdint.h>

void bmt_auth_init(void);

uint16_t bmt_auth_hmac16(const uint8_t* data, size_t len);
