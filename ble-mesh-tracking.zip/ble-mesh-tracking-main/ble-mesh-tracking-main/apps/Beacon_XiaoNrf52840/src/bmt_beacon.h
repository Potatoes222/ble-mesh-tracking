#pragma once

#include <stdbool.h>
#include <stdint.h>

int bmt_beacon_start(void);

uint8_t bmt_beacon_sequence(void);
uint16_t bmt_beacon_last_mac16(void);
bool bmt_beacon_is_active(void);
