#pragma once

void bmt_factory_reset_init(void);
