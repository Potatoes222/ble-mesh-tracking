#pragma once

#include <stdbool.h>
#include <stdint.h>

#include "esp_err.h"
void bmt_mesh_generate_keys_if_needed(void);

esp_err_t bmt_mesh_init(void);

void bmt_mesh_start_node_ping(void);

esp_err_t bmt_mesh_publish(uint16_t dst, uint32_t opcode, const void* data, uint16_t len);
uint32_t bmt_mesh_get_received_count(void);

int bmt_mesh_wipe_all_provisioned(void);

void bmt_mesh_print_keys(void);
