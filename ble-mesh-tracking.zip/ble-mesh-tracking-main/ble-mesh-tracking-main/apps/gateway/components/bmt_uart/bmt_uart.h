#pragma once

void bmt_uart_start(void);
