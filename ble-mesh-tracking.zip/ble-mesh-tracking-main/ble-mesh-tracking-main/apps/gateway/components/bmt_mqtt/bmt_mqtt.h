#pragma once

#include <stdbool.h>

#include "mqtt_client.h"

#include "bmt_types.h"

void bmt_mqtt_init(void);

bool bmt_mqtt_is_connected(void);
esp_mqtt_client_handle_t bmt_mqtt_get_client(void);
void bmt_mqtt_enqueue_tag_report(const bmt_tag_report_t* report, const uint8_t* scanner_mac);

void bmt_mqtt_note_published(void);

void bmt_mqtt_log_stats(void);

void bmt_mqtt_start_worker(void);
