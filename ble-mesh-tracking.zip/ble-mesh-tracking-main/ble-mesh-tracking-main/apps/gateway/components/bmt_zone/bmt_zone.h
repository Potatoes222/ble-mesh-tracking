#pragma once

#include <stdbool.h>
#include <stdint.h>

#define BMT_MAX_SCANNERS 8
#define BMT_MAX_TRACKED_TAGS 16
#define BMT_SCANNER_VALID_MS 3500
#define BMT_TAG_OUT_OF_RANGE_MS 10000
#define BMT_ZONE_UNKNOWN 0xFF

typedef struct
{
	bool active;
	uint16_t tag_id;
	uint8_t battery;
	int8_t rssi_by_scanner[BMT_MAX_SCANNERS];
	uint32_t ts_by_scanner[BMT_MAX_SCANNERS];
	bool valid_by_scanner[BMT_MAX_SCANNERS];
	uint8_t current_zone_id;
	uint32_t last_zone_change_ms, last_any_report_ms;
} bmt_tag_track_t;

void bmt_zone_init(void);

void bmt_zone_lock(void);
void bmt_zone_unlock(void);

int bmt_zone_track_capacity(void);
bmt_tag_track_t* bmt_zone_track_get(int idx);
bmt_tag_track_t* bmt_zone_track_find(uint16_t tag_id);
bmt_tag_track_t* bmt_zone_track_get_or_add(uint16_t tag_id, uint8_t battery);

const char* bmt_zone_name(uint8_t scanner_id);

void bmt_zone_log_tracked(void);

void bmt_zone_reset_all(void);
